using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Books_Management_System.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
